# ClipKey

아이폰용 클립보드 키보드. 복사한 텍스트를 기록해 두고 키보드에서 눌러 붙여넣는다.

## 구조
- `App/` 안내 화면만 있는 본체 앱 (SwiftUI)
- `Keyboard/` 키보드 확장. 기록 저장, 고정, 삭제를 모두 여기서 처리
- `project.yml` XcodeGen 설정. Xcode 프로젝트 파일은 빌드할 때 생성
- `.github/workflows/build.yml` 서명 없는 ipa를 만드는 GitHub Actions

## 빌드
1. 이 폴더를 GitHub 저장소 `main` 브랜치에 올린다.
2. Actions 탭의 "Build IPA"가 끝나면 Artifacts에서 `ClipKey-ipa`를 받는다.
   (zip 안에 `ClipKey.ipa`가 들어 있다)

## 설치 (무료 Apple ID)
1. PC나 Mac에 Sideloadly를 설치하고 아이폰을 케이블로 연결한다.
2. `ClipKey.ipa`를 넣고 Apple ID로 서명해 설치한다.
3. 아이폰 설정 > 일반 > VPN 및 기기 관리에서 내 Apple ID를 신뢰한다.
4. 7일마다 같은 방법으로 다시 설치한다. 기록은 덮어 설치하면 유지된다.

## 키보드 켜기
설정 > 일반 > 키보드 > 키보드 > 새로운 키보드 추가 > ClipKey,
그다음 '클립보드'를 눌러 '전체 접근 허용'을 켠다.
